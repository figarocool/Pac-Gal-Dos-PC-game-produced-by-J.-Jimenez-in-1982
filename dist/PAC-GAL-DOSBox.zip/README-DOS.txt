PAC-GAL — DOSBox edition

This is the DOS/DOSBox build of the PAC-GAL C recreation. It is the project’s
own implementation; the original 1982 game executable is not included.

Requirements: a DPMI host (for example CWSDPMI, installed separately) and
DOSBox with VGA/VESA and Sound Blaster emulation. Mount this folder as drive C,
start your DPMI host at the DOS prompt, then run PACGAL.EXE.

SDL3 is statically linked. Its license is included as SDL3-LICENSE.txt.
Build details and source requirements: https://github.com/figarocool/Pac-Gal-Dos-PC-game-produced-by-J.-Jimenez-in-1982

--- Italiano ---

Questa è la versione DOS/DOSBox della riscrittura C di PAC-GAL. È una
realizzazione del progetto; non include l'eseguibile originale del 1982.

Servono un host DPMI (per esempio CWSDPMI, da installare separatamente) e
DOSBox configurato con VGA/VESA e Sound Blaster. Monta questa cartella come
unità C, avvia l'host DPMI dal prompt DOS, quindi esegui PACGAL.EXE.

SDL3 è collegata staticamente; la relativa licenza è inclusa in SDL3-LICENSE.txt.
